
const imgEL = document.querySelector("img");
const textEL = document.querySelector(".text");
const usernameEL = document.querySelector(".username");

const testimonials = [

    {
        name:  "Rizwan",
        photoURL: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=880&q=80",
        text: "Text 1"

    },
    {
        name:  "Siddiqui",
        photoURL: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=880&q=80",
        text: "Text 2"

    },
    {
        name:  "Ahmded",
        photoURL: "https://images.unsplash.com/photo-1628157588553-5eeea00af15c?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=880&q=80",
        text: "Text 3"

    }

];

let idx = 0;

updateTestimonial()

function updateTestimonial() {
    const { name, photoURL, text } = 
    testimonials[idx];

    imgEL.src = photoURL;
    textEL.innerText = text;
    usernameEL.innerText = name;
    idx++

    if(idx === testimonials.length) {
        idx = 0;
    }

    setTimeout(() => {
        updateTestimonial()
    }, 10000)
}